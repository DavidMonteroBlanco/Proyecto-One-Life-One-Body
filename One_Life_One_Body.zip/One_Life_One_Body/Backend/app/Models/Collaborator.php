<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Collaborator extends Model
{
    protected $fillable = ['name', 'role', 'bio', 'image_url', 'sort_order'];
}
