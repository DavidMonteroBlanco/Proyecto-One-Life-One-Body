Hola <?php echo e($user->name); ?>,

Se te ha asignado un entrenamiento:
- <?php echo e($workout->title); ?> (<?php echo e($workout->duration_minutes); ?> min, <?php echo e($workout->level); ?>)

One Life One Body
<?php /**PATH C:\xampp\htdocs\One_Life_One_Body\Backend\resources\views/emails/workout_assigned.blade.php ENDPATH**/ ?>