import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import PageShell from "../components/PageShell";
import { api, setAuthToken } from "../api";
import { saveToken, saveUser } from "../auth";

export default function Login() {
  const nav = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    setLoading(true);

    try {
      const res = await api.post("/api/login", { email, password });

      const token = res.data?.token;
      const user = res.data?.user;

      if (user) {
        localStorage.setItem("olob_user", JSON.stringify(user));
      }
      if (!token || !user) {
        setMsg("No se pudo iniciar sesión");
        return;
      }

      saveToken(token);
      setAuthToken(token);

      if (user) saveUser(user);

      nav("/", { replace: true });
    } catch (err: any) {
      const m = err?.response?.data?.message;
      setMsg(m ?? "Email o contraseña incorrectos");
    } finally {
      setLoading(false);
    }
  }

  return (
    <PageShell>
      <div className="min-h-[80vh] flex items-center justify-center px-4">
        <div className="relative w-full max-w-md overflow-hidden rounded-xl border border-white/10 bg-black/50 p-6 backdrop-blur">
          <div className="absolute inset-0 bg-black/50 -z-10" />

          <h1 className="text-2xl font-bold text-white">Iniciar sesión</h1>
          <p className="mt-1 text-sm text-white/70">Acceso a One Life One Body</p>

          <form onSubmit={handleSubmit} className="mt-6 grid gap-4">
            <div>
              <label className="block text-sm text-white/80">Email</label>
              <input
                type="email"
                className="mt-1 w-full rounded border border-white/10 bg-white/95 p-2 text-black outline-none focus:ring-2 focus:ring-blue-400"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div>
              <label className="block text-sm text-white/80">Contraseña</label>
              <input
                type="password"
                className="mt-1 w-full rounded border border-white/10 bg-white/95 p-2 text-black outline-none focus:ring-2 focus:ring-blue-400"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="mt-2 rounded p-2 text-white transition"
              style={{ backgroundColor: "var(--blue-light)" }}
            >
              {loading ? "Entrando..." : "Entrar"}
            </button>

            {msg && <p className="text-sm text-red-300">{msg}</p>}

            <div className="mt-2 flex justify-between text-sm text-white/70">
              <Link to="/forgot" className="hover:underline">
                ¿Olvidaste tu contraseña?
              </Link>
              <Link to="/register" className="hover:underline">
                Crear cuenta
              </Link>
            </div>
          </form>
        </div>
      </div>
    </PageShell>
  );
}
