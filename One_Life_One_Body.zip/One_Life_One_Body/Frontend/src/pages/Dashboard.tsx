import PageShell from "../components/PageShell";

export default function Dashboard() {
  return (
    <PageShell>
      <div className="space-y-6">
        <div className="olob-card">
          <div className="text-xs uppercase tracking-wide olob-muted">
            Panel interno
          </div>

          <h1 className="mt-2 text-3xl font-bold" style={{ color: "var(--blue-dark)" }}>
            One Life One Body
          </h1>

          <p className="mt-2 olob-muted">
            Gestión de entrenamientos, favoritos y contenidos de la web. Usa el botón{" "}
            <strong>Menú</strong> de arriba para moverte por las secciones.
          </p>
        </div>

        <div className="olob-card">
          <h2 className="text-xl font-bold" style={{ color: "var(--blue-dark)" }}>
            Estado del sistema
          </h2>

          <ul className="mt-3 list-disc pl-5 olob-muted">
            <li>API: lista para usar</li>
            <li>Sesión: protegida por token</li>
            <li>Rol: controla lo que ves (admin / user)</li>
          </ul>
        </div>

        <div className="olob-card">
          <h2 className="text-xl font-bold" style={{ color: "var(--blue-dark)" }}>
            Nota rápida
          </h2>

          <p className="mt-2 olob-muted">
            El panel no muestra enlaces aquí porque el acceso principal es el{" "}
            <strong>Menú</strong> desplegable del Navbar (y cambia según rol).
          </p>
        </div>
      </div>
    </PageShell>
  );
}
