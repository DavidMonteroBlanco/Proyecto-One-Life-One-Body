import { Link, useNavigate } from "react-router-dom";
import { useEffect, useMemo, useState } from "react";
import { getToken, clearToken, saveUser, clearUser } from "../auth";
import { setAuthToken } from "../api";
import { fetchMe } from "../authSession";

type MeUser = {
  name?: string;
  role?: "admin" | "user" | string;
};

const THEME_KEY = "olob_theme";

function applyTheme(mode: "light" | "dark") {
  const root = document.documentElement;
  if (mode === "dark") root.classList.add("dark");
  else root.classList.remove("dark");
  localStorage.setItem(THEME_KEY, mode);
}

function getInitialTheme(): "light" | "dark" {
  const saved = localStorage.getItem(THEME_KEY);
  if (saved === "dark" || saved === "light") return saved;
  return "dark"; 
}

export default function Navbar() {
  const nav = useNavigate();
  const [user, setUser] = useState<MeUser | null>(null);
  const token = getToken();

  const admin = useMemo(() => user?.role === "admin", [user]);

  const [menuOpen, setMenuOpen] = useState(false);
  const [theme, setTheme] = useState<"light" | "dark">(getInitialTheme());

  useEffect(() => {
  document.body.classList.remove("light", "dark");
  document.body.classList.add(theme);
  localStorage.setItem("olob_theme", theme);
}, [theme]);

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  useEffect(() => {
    if (!token) {
      setUser(null);
      return;
    }

    fetchMe()
      .then((u: any) => {
        setUser(u);
        saveUser(u);
      })
      .catch(() => setUser(null));
  }, [token]);

  function handleLogout() {
    clearToken();
    clearUser();
    setAuthToken(null);
    setUser(null);
    nav("/login");
  }

  function toggleTheme() {
    setTheme((t) => (t === "dark" ? "light" : "dark"));
  }

  function go(path: string) {
    setMenuOpen(false);
    nav(path);
  }

  return (
    <header
      className="sticky top-0 z-50 border-b"
      style={{ backgroundColor: "var(--nav-bg)", borderColor: "var(--nav-border)" }}
    >
      <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
        <div className="flex items-center gap-3">
          <img
            src="/LOGO-OLB CHICA.jpg"
            alt="One Life One Body"
            style={{
              width: 38,
              height: 38,
              objectFit: "contain",
              borderRadius: 10,
              background: "white",
              padding: 4,
            }}
          />

          <div className="leading-tight">
            <div className="text-white font-semibold">ONE LIFE ONE BODY</div>
            <div className="text-white/70 text-xs">Gym • App interna</div>
          </div>
        </div>

        <div className="flex items-center gap-10">
          {token ? (
            <div className="hidden sm:block text-sm text-white/80">
              Hola, {user?.name ?? "Usuario"} {admin ? "(Admin)" : ""}
            </div>
          ) : (
            <div className="hidden sm:block text-sm text-white/70">
              No autenticado
            </div>
          )}

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={toggleTheme}
              className="rounded px-3 py-1 text-sm text-white"
              style={{ backgroundColor: "var(--chip-bg)", border: "1px solid var(--chip-border)" }}
              title="Cambiar modo"
            >
              {theme === "dark" ? "☾ Oscuro" : "☀ Claro"}
            </button>

            {token && (
              <button
                type="button"
                onClick={() => setMenuOpen((v) => !v)}
                className="rounded px-3 py-1 text-sm text-white"
                style={{ backgroundColor: "var(--blue-light)" }}
              >
                Menú ☰
              </button>
            )}

            {token ? (
              <button
                onClick={handleLogout}
                className="rounded px-3 py-1 text-sm text-white"
                style={{ backgroundColor: "rgba(255,255,255,0.12)", border: "1px solid rgba(255,255,255,0.14)" }}
              >
                Logout
              </button>
            ) : (
              <Link
                to="/login"
                className="rounded px-3 py-1 text-sm text-white"
                style={{ backgroundColor: "var(--blue-light)" }}
              >
                Login
              </Link>
            )}
          </div>
        </div>
      </div>

      {token && menuOpen && (
        <div className="mx-auto max-w-5xl px-4 pb-3">
          <div className="olob-menu-panel">
            <div className="text-white/80 text-sm mb-2">
              {admin ? "Zona Admin" : "Zona Usuario"}
            </div>

            <div className="olob-navlinks">
              <button className="olob-navlink" onClick={() => go("/")}>
                Dashboard
              </button>

              <button className="olob-navlink" onClick={() => go("/workouts")}>
                Entrenamientos
              </button>

              <button className="olob-navlink" onClick={() => go("/exercises")}>
                Ejercicios (API externa)
              </button>

              <button className="olob-navlink" onClick={() => go("/saved-exercises")}>
                Favoritos
              </button>

              {admin && (
                <>
                  <span className="olob-navlink olob-navlink-muted">|</span>

                  <button
                    className="olob-navlink olob-navlink-admin"
                    onClick={() => go("/admin/services")}
                  >
                    Servicios (Admin)
                  </button>

                  <button
                    className="olob-navlink olob-navlink-admin"
                    onClick={() => go("/admin/collaborators")}
                  >
                    Colaboradores (Admin)
                  </button>

                  <button
                    className="olob-navlink olob-navlink-admin"
                    onClick={() => go("/admin/method")}
                  >
                    Método (Admin)
                  </button>

                  <button
                    className="olob-navlink olob-navlink-admin"
                    onClick={() => go("/admin/settings")}
                  >
                    Configuración (Admin)
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
